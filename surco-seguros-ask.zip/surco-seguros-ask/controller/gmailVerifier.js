const fs = require('fs');
const readline = require('readline');
const {google} = require('googleapis');
var Spinner = require('cli-spinner').Spinner;
Spinner.setDefaultSpinnerString(10)

// If modifying these scopes, delete token.json.
const SCOPES = ['https://www.googleapis.com/auth/gmail.readonly'];
// The file token.json stores the user's access and refresh tokens, and is
// created automatically when the authorization flow completes for the first
// time.
const TOKEN_PATH = 'token.json';


// Load client secrets from a local file.
exports.checkEmail = async function() {
    fs.readFile('credentials.json', (err, content) => {
        if (err) return console.log('Error loading client secret file:', err);
        // Authorize a client with credentials, then call the Gmail API.
        authorize(JSON.parse(content), listMessages);
    });
}

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
async function authorize(credentials, callback) {
    const {client_secret, client_id, redirect_uris} = credentials.installed;
    const oAuth2Client = new google.auth.OAuth2(
        client_id, client_secret, redirect_uris[0]);

    // Check if we have previously stored a token.
    fs.readFile(TOKEN_PATH, (err, token) => {
        if (err) return getNewToken(oAuth2Client, callback);
        oAuth2Client.setCredentials(JSON.parse(token));
        callback(oAuth2Client);
    });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 * @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback for the authorized client.
 */
function getNewToken(oAuth2Client, callback) {
    const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: SCOPES,
    });
    console.log('Authorize this app by visiting this url:', authUrl);
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });
    rl.question('Enter the code from that page here: ', (code) => {
        rl.close();
        oAuth2Client.getToken(code, (err, token) => {
            if (err) return console.error('Error retrieving access token', err);
            oAuth2Client.setCredentials(token);
            // Store the token to disk for later program executions
            fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
                if (err) return console.error(err);
                console.log('Token stored to', TOKEN_PATH);
            });
            callback(oAuth2Client);
        });
    });
}

/**
 * Lists the labels in the user's account.
 *
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */
async function listMessages(auth) {
    const gmail = google.gmail({version: 'v1', auth});
    var spinnerObj = new Spinner({
        text: 'Listando Emails.. %s',
        stream: process.stderr,
        onTick: function(msg){
            this.clearLine(this.stream);
            this.stream.write(msg);
        }
    })
    spinnerObj.start();
    await gmail.users.messages.list({
        userId: 'me',
        q:'from:cliente@surco.com.uy',
        maxResults:'1',
        includeSpamTrash:false
    }, async (err, res) => {
        if (err) return console.log('The API returned an error: ' + err);
        spinnerObj.stop();
        getSurcoEmailInfo(auth,res.data.messages[0].id);
    });

}

function getSurcoEmailInfo(auth,msgId){
    const gmail = google.gmail({version: 'v1', auth});
    var spinnerObj = new Spinner({
        text: 'Leyendo el Email!.. %s',
        stream: process.stderr,
        onTick: function(msg){
            this.clearLine(this.stream);
            this.stream.write(msg);
        }
    })
    spinnerObj.start();
    gmail.users.messages.get({
        userId:'me',
        id:msgId
    },async (err,res)=>{
        if(err) console.log(err);
        await spinnerObj.stop();
        var date = new Date(res.headers.date);
        console.log('Hora del email: ',date.getHours()+':'+date.getMinutes())
        getSurcoPDF(auth,msgId,res.data.payload.parts[1].body.attachmentId);
    })
}


function getSurcoPDF(auth,msgId,attachmentId){
    const gmail = google.gmail({version: 'v1', auth});
    var spinnerObj = new Spinner({
        text: 'Leyendo el PDF!.. %s',
        stream: process.stderr,
        onTick: function(msg){
            this.clearLine(this.stream);
            this.stream.write(msg);
        }
    })
    spinnerObj.start();
    gmail.users.messages.attachments.get({
        userId:'me',
        messageId:msgId,
        id:attachmentId
    },async (err,res)=>{
        if(err) console.log(err);
        await spinnerObj.stop();
        readPDF(res.data.data);
    })
}

const pdfreader = require("pdfreader");

var rows = {};
function readPDF(data){
    var result = decodeBase64(data);

    fs.writeFile('result_binary.pdf', result, 'binary', error => {
        if (error) {
            throw error;
        }
    });
    setTimeout(function() {
    }, 3000);
    new pdfreader.PdfReader().parseFileItems("result_binary.pdf", function (err, item) {
        if (!item) {
            // end of file, or page
            var keys = Object.keys(rows);
            var last = keys[keys.length-1];
            if(last!=='19.213'){
                sendNotification(rows[last]);
            } else{
                console.log('nada nuevo');
            }
        } else if (item.text) {
            // accumulate text items into rows object, per line
            (rows[item.y] = rows[item.y] || []).push(item.text);
        }
    });
}
const notifier = require('node-notifier');
function sendNotification(update) {
// String
    notifier.notify('SURCO UPDATE!!');

// Object
    notifier.notify({
        title: 'Tenemos update de surco',
        message: update,
        sound: true
    });
}

const Base64 = require('js-base64')
function decodeBase64(str) {
    str = str.replace(/_/g, '/').replace(/-/g, '+') // important line
    return Base64.atob(str)
}

