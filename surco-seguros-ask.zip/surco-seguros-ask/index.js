const {makeSurcoRequest} = require('./controller/surcoRequest')
const {checkEmail} = require('./controller/gmailVerifier')
var Spinner = require('cli-spinner').Spinner;
var schedule = require('node-schedule');
Spinner.setDefaultSpinnerString(10)
async function doTheMagic(){
    await makeSurcoRequest();
    var spinnerObj = new Spinner({
        text: 'Haciendo la request a Surco.. %s',
        stream: process.stderr,
        onTick: function(msg){
            this.clearLine(this.stream);
            this.stream.write(msg);
        }
    })
    spinnerObj.start();
    setTimeout(function() {
    }, 5000);
    await spinnerObj.stop();
    await checkEmail();
}
doTheMagic();
var timeExecuted = 0;

var job = schedule.scheduleJob('0 0 * ? * *', function(){
    timeExecuted++;
    console.log('Times Executed: ',timeExecuted);
    doTheMagic();
});
job.nextInvocation();



